import 'package:generic_bloc_provider/generic_bloc_provider.dart';

class Bloc2 implements Bloc {
  @override
  void dispose() {}
}
